SHIFANA & ZABEEL WEDDING WEBSITE

Files:
- index.html
- assets/ (your uploaded photos)

To publish with GitHub Pages:
1. Extract this ZIP.
2. Upload index.html and the complete assets folder to the ROOT of your GitHub repository.
3. In GitHub: Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
4. Wait for the published URL to appear in Settings -> Pages.

Notes:
- The Google Maps button opens a search for Fousiya Auditorium, Erattupetta.
- The Live Stream section is a placeholder until you provide a streaming URL.
- The countdown is set for 15 February 2027, 12:00 PM India time (IST).
